
public class Anneau {
	int taille;
	public Anneau(int x) {
		taille = x;
	}
}
